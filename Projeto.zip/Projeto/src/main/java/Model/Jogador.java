/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


/**
 *
 * @author Luis Fernando
 */
public class Jogador {
    private String nome;   
    private int dia, mes, ano;
    private String senha;
    private int pontos;
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public void setSenha(String senha) {
        this.senha = senha.toLowerCase();
    }

    public int getPontos() {
        return pontos;
    }

    public boolean verificarUsuario(String nome, String senha){
      if(nome.equals(this.nome)&& senha.equals(this.senha)){
          return true;
      }
      return false;
    }
    
    public Jogador(String nome, String senha){
        setNome(nome);
        setSenha(senha);
    }
    public Jogador(){
        
    }   
   
    public void pontuar(boolean acerto){
        if(acerto){
            this.pontos += 3;
        }
        else{
            this.pontos -= -1;
        }
    }  
}
