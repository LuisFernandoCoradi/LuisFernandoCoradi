/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author Luis Fernando
 */
public class Questoes {
    private ArrayList<String> perguntas;
    private String[][] alternativas;
    private int[] correta;
    private int qtd_alternativas;
    
    public Questoes(int qtd_perguntas, int qtd_alternativas){
        perguntas = new ArrayList();
        alternativas = new String[qtd_perguntas][qtd_alternativas];
        correta = new int[qtd_perguntas];
        this.qtd_alternativas = qtd_alternativas;
    }
    
    public ArrayList<String> getPerguntas() {
        return perguntas;
    }

    public void setPerguntas(ArrayList<String> perguntas) {
        this.perguntas = perguntas;
    }

    public String[][] getAlternativas() {
        return alternativas;
    }

    public void setAlternativas(String[][] alternativas) {
        this.alternativas = alternativas;
    }

    public int[] getCorreta() {
        return correta;
    }

    public void setCorreta(int[] correta) {
        this.correta = correta;
    }
    
    public int getQtd_Alternativas(){
        return this.qtd_alternativas;
    }
    
public boolean acertou(int resposta, int pergunta){
    if(correta[pergunta] == resposta){
        return true;
    }
    return false;
}
}
