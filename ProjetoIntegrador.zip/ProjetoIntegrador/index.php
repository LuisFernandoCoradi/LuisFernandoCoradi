<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="projeto.css">
<meta charset="utf-8">
</head>
<body>
<header class="header">
	<h1 align="Center">Clínica Odontológica - UNISAGRADO</h1>
</header>
<h3 class="class">

		<a href="index.php" class="class">Home </a> | 
		<a href="Usuarios.php" class="class">Usuarios Cadastrados </a> | 
		<a href="projeto.php" class="class">Cadastrar Novo </a> | 

</h3>

<table>
	<tr>
		<td>
			<img src="images/foto1.jpg" width="495">
		</td>
		<td>
			<img src="images/foto2.jpg" width="495">
		</td>
		<td>
			<img src="images/foto3.jpg" width="495">
		</td>
		<td>
			<img src="images/foto7.jpg" width="495">
		</td>
	</tr>	
	<tr>
		<td>
			<img src="images/foto4.jpg" width="495">
		</td>
		<td>
			<img src="images/foto5.jpg" width="495">
		</td>
		<td>
			<img src="images/foto6.jpg" width="495">
		</td>		
		<td>
			<img src="images/foto8.jpg" width="495">
		</td>
	</tr>
</table>

</body>
</html>