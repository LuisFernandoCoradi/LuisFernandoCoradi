<?php
	$acao = 'remover';
	require 'cadastro_controller.php';
?>