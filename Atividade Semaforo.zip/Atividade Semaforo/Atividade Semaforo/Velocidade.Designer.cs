﻿namespace Atividade_Semaforo
{
    partial class Velocidade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DistanciaTxt = new System.Windows.Forms.TextBox();
            this.LblDistancia = new System.Windows.Forms.Label();
            this.LblTempoGasto = new System.Windows.Forms.Label();
            this.TxtTempGasto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LblVelMedia = new System.Windows.Forms.Label();
            this.LblVelMaxPermitida = new System.Windows.Forms.Label();
            this.Txtvelocmaxperm = new System.Windows.Forms.TextBox();
            this.Lblkmhoras = new System.Windows.Forms.Label();
            this.Txtvelocidademedia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btNovo = new System.Windows.Forms.Button();
            this.btCalcular = new System.Windows.Forms.Button();
            this.btVisualizar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DistanciaTxt
            // 
            this.DistanciaTxt.Location = new System.Drawing.Point(89, 32);
            this.DistanciaTxt.Name = "DistanciaTxt";
            this.DistanciaTxt.Size = new System.Drawing.Size(100, 20);
            this.DistanciaTxt.TabIndex = 0;
            // 
            // LblDistancia
            // 
            this.LblDistancia.AutoSize = true;
            this.LblDistancia.Location = new System.Drawing.Point(12, 35);
            this.LblDistancia.Name = "LblDistancia";
            this.LblDistancia.Size = new System.Drawing.Size(54, 13);
            this.LblDistancia.TabIndex = 1;
            this.LblDistancia.Text = "Distancia:";
            // 
            // LblTempoGasto
            // 
            this.LblTempoGasto.AutoSize = true;
            this.LblTempoGasto.Location = new System.Drawing.Point(12, 72);
            this.LblTempoGasto.Name = "LblTempoGasto";
            this.LblTempoGasto.Size = new System.Drawing.Size(71, 13);
            this.LblTempoGasto.TabIndex = 2;
            this.LblTempoGasto.Text = "Tempo Gasto";
            // 
            // TxtTempGasto
            // 
            this.TxtTempGasto.Location = new System.Drawing.Point(89, 69);
            this.TxtTempGasto.Name = "TxtTempGasto";
            this.TxtTempGasto.Size = new System.Drawing.Size(100, 20);
            this.TxtTempGasto.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(195, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Km";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(195, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Horas";
            // 
            // LblVelMedia
            // 
            this.LblVelMedia.AutoSize = true;
            this.LblVelMedia.Location = new System.Drawing.Point(122, 304);
            this.LblVelMedia.Name = "LblVelMedia";
            this.LblVelMedia.Size = new System.Drawing.Size(95, 13);
            this.LblVelMedia.TabIndex = 6;
            this.LblVelMedia.Text = "Velocidade Media:";
            // 
            // LblVelMaxPermitida
            // 
            this.LblVelMaxPermitida.AutoSize = true;
            this.LblVelMaxPermitida.Location = new System.Drawing.Point(377, 39);
            this.LblVelMaxPermitida.Name = "LblVelMaxPermitida";
            this.LblVelMaxPermitida.Size = new System.Drawing.Size(145, 13);
            this.LblVelMaxPermitida.TabIndex = 7;
            this.LblVelMaxPermitida.Text = "Velocidade Maxima Permitida";
            // 
            // Txtvelocmaxperm
            // 
            this.Txtvelocmaxperm.Location = new System.Drawing.Point(380, 65);
            this.Txtvelocmaxperm.Name = "Txtvelocmaxperm";
            this.Txtvelocmaxperm.Size = new System.Drawing.Size(100, 20);
            this.Txtvelocmaxperm.TabIndex = 8;
            // 
            // Lblkmhoras
            // 
            this.Lblkmhoras.AutoSize = true;
            this.Lblkmhoras.Location = new System.Drawing.Point(486, 69);
            this.Lblkmhoras.Name = "Lblkmhoras";
            this.Lblkmhoras.Size = new System.Drawing.Size(48, 13);
            this.Lblkmhoras.TabIndex = 9;
            this.Lblkmhoras.Text = "Km/hora";
            // 
            // Txtvelocidademedia
            // 
            this.Txtvelocidademedia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Txtvelocidademedia.Location = new System.Drawing.Point(233, 297);
            this.Txtvelocidademedia.Name = "Txtvelocidademedia";
            this.Txtvelocidademedia.ReadOnly = true;
            this.Txtvelocidademedia.Size = new System.Drawing.Size(100, 20);
            this.Txtvelocidademedia.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(349, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Km/hora";
            // 
            // btNovo
            // 
            this.btNovo.Location = new System.Drawing.Point(12, 415);
            this.btNovo.Name = "btNovo";
            this.btNovo.Size = new System.Drawing.Size(177, 23);
            this.btNovo.TabIndex = 12;
            this.btNovo.Text = "Novo";
            this.btNovo.UseVisualStyleBackColor = true;
            // 
            // btCalcular
            // 
            this.btCalcular.Location = new System.Drawing.Point(284, 415);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(196, 23);
            this.btCalcular.TabIndex = 13;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = true;
            this.btCalcular.Click += new System.EventHandler(this.button2_Click);
            // 
            // btVisualizar
            // 
            this.btVisualizar.Location = new System.Drawing.Point(579, 415);
            this.btVisualizar.Name = "btVisualizar";
            this.btVisualizar.Size = new System.Drawing.Size(186, 23);
            this.btVisualizar.TabIndex = 14;
            this.btVisualizar.Text = "Visualizar";
            this.btVisualizar.UseVisualStyleBackColor = true;
            this.btVisualizar.Click += new System.EventHandler(this.btVisualizar_Click);
            // 
            // Velocidade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btVisualizar);
            this.Controls.Add(this.btCalcular);
            this.Controls.Add(this.btNovo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Txtvelocidademedia);
            this.Controls.Add(this.Lblkmhoras);
            this.Controls.Add(this.Txtvelocmaxperm);
            this.Controls.Add(this.LblVelMaxPermitida);
            this.Controls.Add(this.LblVelMedia);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtTempGasto);
            this.Controls.Add(this.LblTempoGasto);
            this.Controls.Add(this.LblDistancia);
            this.Controls.Add(this.DistanciaTxt);
            this.Name = "Velocidade";
            this.Text = "Velocidade";
            this.Load += new System.EventHandler(this.Velocidade_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox DistanciaTxt;
        private System.Windows.Forms.Label LblDistancia;
        private System.Windows.Forms.Label LblTempoGasto;
        private System.Windows.Forms.TextBox TxtTempGasto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblVelMedia;
        private System.Windows.Forms.Label LblVelMaxPermitida;
        private System.Windows.Forms.TextBox Txtvelocmaxperm;
        private System.Windows.Forms.Label Lblkmhoras;
        private System.Windows.Forms.TextBox Txtvelocidademedia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btNovo;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.Button btVisualizar;
    }
}