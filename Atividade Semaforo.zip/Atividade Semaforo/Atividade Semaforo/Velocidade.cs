﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_Semaforo
{
    public partial class Velocidade : Form
    {
        public Velocidade()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            float dist = 0, tempogasto = 0,velmedia = 0;
            if (String.IsNullOrEmpty(DistanciaTxt.Text) || String.IsNullOrEmpty(TxtTempGasto.Text))
            {
                MessageBox.Show("preencher os campos");
            }
            else
            {
                dist = float.Parse(DistanciaTxt.Text);

                tempogasto = float.Parse(TxtTempGasto.Text);
                velmedia = (dist / tempogasto);
                Txtvelocidademedia.Text = velmedia.ToString();
            }
            
        }

        private void Velocidade_Load(object sender, EventArgs e)
        {

        }
        private void btVisualizar_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Txtvelocidademedia.Text) || String.IsNullOrEmpty(Txtvelocmaxperm.Text) || String.IsNullOrEmpty(DistanciaTxt.Text) || String.IsNullOrEmpty(TxtTempGasto.Text))
            {
                MessageBox.Show("Informações faltando");
            }
            else { 
            this.Hide();
            Visualizacao formDestino = new Visualizacao(Txtvelocmaxperm.Text, Txtvelocidademedia.Text);
            formDestino.Show();
        }
        }
    }
}
