﻿namespace Atividade_Semaforo
{
    partial class Visualizacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Lblvelmaxperm = new System.Windows.Forms.Label();
            this.Txtvelocmaxperm = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Lblvelmedia = new System.Windows.Forms.Label();
            this.Txtvelocidademedia = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LblQtde = new System.Windows.Forms.Label();
            this.TxtQtde = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btFechar = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.LblMensagem = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Lblvelmaxperm
            // 
            this.Lblvelmaxperm.AutoSize = true;
            this.Lblvelmaxperm.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblvelmaxperm.Location = new System.Drawing.Point(12, 27);
            this.Lblvelmaxperm.Name = "Lblvelmaxperm";
            this.Lblvelmaxperm.Size = new System.Drawing.Size(130, 13);
            this.Lblvelmaxperm.TabIndex = 0;
            this.Lblvelmaxperm.Text = "Velocidade Permitida:";
            // 
            // Txtvelocmaxperm
            // 
            this.Txtvelocmaxperm.Location = new System.Drawing.Point(140, 24);
            this.Txtvelocmaxperm.Name = "Txtvelocmaxperm";
            this.Txtvelocmaxperm.Size = new System.Drawing.Size(74, 20);
            this.Txtvelocmaxperm.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(220, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Km/h";
            // 
            // Lblvelmedia
            // 
            this.Lblvelmedia.AutoSize = true;
            this.Lblvelmedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblvelmedia.Location = new System.Drawing.Point(12, 55);
            this.Lblvelmedia.Name = "Lblvelmedia";
            this.Lblvelmedia.Size = new System.Drawing.Size(112, 13);
            this.Lblvelmedia.TabIndex = 3;
            this.Lblvelmedia.Text = "Velocidade Media:";
            // 
            // Txtvelocidademedia
            // 
            this.Txtvelocidademedia.Location = new System.Drawing.Point(140, 50);
            this.Txtvelocidademedia.Name = "Txtvelocidademedia";
            this.Txtvelocidademedia.Size = new System.Drawing.Size(74, 20);
            this.Txtvelocidademedia.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(220, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Km/h";
            // 
            // LblQtde
            // 
            this.LblQtde.AutoSize = true;
            this.LblQtde.Location = new System.Drawing.Point(12, 322);
            this.LblQtde.Name = "LblQtde";
            this.LblQtde.Size = new System.Drawing.Size(62, 13);
            this.LblQtde.TabIndex = 6;
            this.LblQtde.Text = "Qtde Km/h:";
            // 
            // TxtQtde
            // 
            this.TxtQtde.Location = new System.Drawing.Point(80, 315);
            this.TxtQtde.Name = "TxtQtde";
            this.TxtQtde.Size = new System.Drawing.Size(100, 20);
            this.TxtQtde.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 287);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Velocidade ACIMA do indicado:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(503, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 365);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btFechar
            // 
            this.btFechar.Location = new System.Drawing.Point(713, 415);
            this.btFechar.Name = "btFechar";
            this.btFechar.Size = new System.Drawing.Size(75, 23);
            this.btFechar.TabIndex = 10;
            this.btFechar.Text = "Fechar";
            this.btFechar.UseVisualStyleBackColor = true;
            this.btFechar.Click += new System.EventHandler(this.btFechar_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // LblMensagem
            // 
            this.LblMensagem.AutoSize = true;
            this.LblMensagem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblMensagem.ForeColor = System.Drawing.Color.Red;
            this.LblMensagem.Location = new System.Drawing.Point(12, 418);
            this.LblMensagem.Name = "LblMensagem";
            this.LblMensagem.Size = new System.Drawing.Size(88, 20);
            this.LblMensagem.TabIndex = 11;
            this.LblMensagem.Text = "Mensagem";
            // 
            // Visualizacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.LblMensagem);
            this.Controls.Add(this.btFechar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtQtde);
            this.Controls.Add(this.LblQtde);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Txtvelocidademedia);
            this.Controls.Add(this.Lblvelmedia);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Txtvelocmaxperm);
            this.Controls.Add(this.Lblvelmaxperm);
            this.Name = "Visualizacao";
            this.Text = "Visualizacao";
            this.Load += new System.EventHandler(this.Visualizacao_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lblvelmaxperm;
        private System.Windows.Forms.TextBox Txtvelocmaxperm;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lblvelmedia;
        private System.Windows.Forms.TextBox Txtvelocidademedia;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblQtde;
        private System.Windows.Forms.TextBox TxtQtde;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btFechar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LblMensagem;
    }
}