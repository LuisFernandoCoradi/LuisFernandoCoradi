﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Atividade_Semaforo
{
    public partial class Visualizacao : Form
    {
        public Visualizacao(string valor1, string vm)
        {
            InitializeComponent();
            float acima = 0, permitida = 0, media = 0;
            string path = Directory.GetCurrentDirectory();
            
                Txtvelocmaxperm.Text = valor1;
                Txtvelocidademedia.Text = vm;
            
                permitida = float.Parse(valor1);
           
            media = float.Parse(vm);
            if(media>permitida)
            {
                timer1.Enabled = true;
                acima = (media - permitida);
                TxtQtde.Text = acima.ToString();
                pictureBox1.Image = Image.FromFile("Sinal_vermelho.JPG");
                LblMensagem.Text = "RESPEITE OS LIMITES DE VELOCIDADE";

            }
            else
            {
                TxtQtde.Text = "";
                LblMensagem.Text = "";
                pictureBox1.Image = Image.FromFile("Sinal_verde.JPG");
                LblMensagem.ForeColor = Color.Blue;
                LblMensagem.Text = "Voce esta dentro do limite de velocidade";

            }

        }
        private void Visualizacao_Load(object sender, EventArgs e)
        {

        }
        private void btFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LblMensagem.ForeColor = LblMensagem.ForeColor == Color.Red ? Color.Black : Color.Red;
        }
    }
}
