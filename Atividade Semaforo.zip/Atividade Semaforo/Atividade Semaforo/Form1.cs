﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Atividade_Semaforo
{
    public partial class FLogin : Form
    { string senha;
        public FLogin()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void FLogin_Load(object sender, EventArgs e)
        {

        }
        private void btOk_Click(object sender, EventArgs e)
        {
            senha = Senhatext.Text;
            if (senha =="unisagrado")
            { this.Hide();
                MessageBox.Show("Logado com sucesso");
                Velocidade formDestino = new Velocidade();
                formDestino.Show();
            }
            else
            {
                MessageBox.Show("Senha inválida","Validação de login",MessageBoxButtons.OK, MessageBoxIcon.Error);
                Senhatext.Text = "";
                Senhatext.Focus();
                
            }
        }
        private void btSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
