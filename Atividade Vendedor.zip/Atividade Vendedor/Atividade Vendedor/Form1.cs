﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Atividade_Vendedor
{
    public partial class Form1 : Form
    {
        double salarioBruto, ValorVenda, SalarioReceber;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LblSalarioBruto_Click(object sender, EventArgs e)
        {

        }

        private void RbVendedor_CheckedChanged(object sender, EventArgs e)
        {
            
            TxtValordaVenda.ReadOnly = false;
        }

        private void RbOutra_CheckedChanged(object sender, EventArgs e)
        {
            
            TxtValordaVenda.ReadOnly = true;
        }

        private void BtCalcula_Click(object sender, EventArgs e)
        {
            salarioBruto = Double.Parse(TxtSalarioBruto.Text);
            if (RbVendedor.Checked == true)
            {
                if (String.IsNullOrEmpty(TxtValordaVenda.Text))
                {
                    MessageBox.Show("Informar valor da venda");
                }
                else
                {
                    ValorVenda = double.Parse(TxtValordaVenda.Text);
                    SalarioReceber = ((ValorVenda * 15) / 100) + salarioBruto;
                    TxtSalarioReceber.Text = SalarioReceber.ToString("C", CultureInfo.CurrentCulture);
                }
            }
            else
            {
                TxtSalarioReceber.Text = salarioBruto.ToString("C", CultureInfo.CurrentCulture);
            }
        }

        private void LblValorVenda_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {   
            TxtValordaVenda.ReadOnly = true;
        }
    }
}
