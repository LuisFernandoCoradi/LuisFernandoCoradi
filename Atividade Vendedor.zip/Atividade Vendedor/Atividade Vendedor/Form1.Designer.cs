﻿namespace Atividade_Vendedor
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.GroupBFunção = new System.Windows.Forms.GroupBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.LblSalarioBruto = new System.Windows.Forms.Label();
            this.TxtSalarioBruto = new System.Windows.Forms.TextBox();
            this.RbVendedor = new System.Windows.Forms.RadioButton();
            this.RbOutra = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LblValorVenda = new System.Windows.Forms.Label();
            this.TxtValordaVenda = new System.Windows.Forms.TextBox();
            this.LblSalarioaReceber = new System.Windows.Forms.Label();
            this.TxtSalarioReceber = new System.Windows.Forms.TextBox();
            this.BtCalcula = new System.Windows.Forms.Button();
            this.GroupBFunção.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 31);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(38, 13);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome:";
            this.lblNome.Click += new System.EventHandler(this.label1_Click);
            // 
            // GroupBFunção
            // 
            this.GroupBFunção.Controls.Add(this.RbOutra);
            this.GroupBFunção.Controls.Add(this.RbVendedor);
            this.GroupBFunção.Location = new System.Drawing.Point(15, 204);
            this.GroupBFunção.Name = "GroupBFunção";
            this.GroupBFunção.Size = new System.Drawing.Size(200, 100);
            this.GroupBFunção.TabIndex = 1;
            this.GroupBFunção.TabStop = false;
            this.GroupBFunção.Text = "Função";
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(53, 28);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(295, 20);
            this.TxtNome.TabIndex = 2;
            // 
            // LblSalarioBruto
            // 
            this.LblSalarioBruto.AutoSize = true;
            this.LblSalarioBruto.Location = new System.Drawing.Point(12, 72);
            this.LblSalarioBruto.Name = "LblSalarioBruto";
            this.LblSalarioBruto.Size = new System.Drawing.Size(70, 13);
            this.LblSalarioBruto.TabIndex = 3;
            this.LblSalarioBruto.Text = "Salario Bruto:";
            this.LblSalarioBruto.Click += new System.EventHandler(this.LblSalarioBruto_Click);
            // 
            // TxtSalarioBruto
            // 
            this.TxtSalarioBruto.Location = new System.Drawing.Point(88, 69);
            this.TxtSalarioBruto.Name = "TxtSalarioBruto";
            this.TxtSalarioBruto.Size = new System.Drawing.Size(127, 20);
            this.TxtSalarioBruto.TabIndex = 4;
            // 
            // RbVendedor
            // 
            this.RbVendedor.AutoSize = true;
            this.RbVendedor.Location = new System.Drawing.Point(6, 29);
            this.RbVendedor.Name = "RbVendedor";
            this.RbVendedor.Size = new System.Drawing.Size(71, 17);
            this.RbVendedor.TabIndex = 0;
            this.RbVendedor.Text = "Vendedor";
            this.RbVendedor.UseVisualStyleBackColor = true;
            this.RbVendedor.CheckedChanged += new System.EventHandler(this.RbVendedor_CheckedChanged);
            // 
            // RbOutra
            // 
            this.RbOutra.AutoSize = true;
            this.RbOutra.Location = new System.Drawing.Point(6, 61);
            this.RbOutra.Name = "RbOutra";
            this.RbOutra.Size = new System.Drawing.Size(51, 17);
            this.RbOutra.TabIndex = 1;
            this.RbOutra.Text = "Outra";
            this.RbOutra.UseVisualStyleBackColor = true;
            this.RbOutra.CheckedChanged += new System.EventHandler(this.RbOutra_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtSalarioReceber);
            this.groupBox1.Controls.Add(this.LblSalarioaReceber);
            this.groupBox1.Controls.Add(this.TxtValordaVenda);
            this.groupBox1.Controls.Add(this.LblValorVenda);
            this.groupBox1.Location = new System.Drawing.Point(473, 204);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 100);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // LblValorVenda
            // 
            this.LblValorVenda.AutoSize = true;
            this.LblValorVenda.Location = new System.Drawing.Point(6, 29);
            this.LblValorVenda.Name = "LblValorVenda";
            this.LblValorVenda.Size = new System.Drawing.Size(85, 13);
            this.LblValorVenda.TabIndex = 0;
            this.LblValorVenda.Text = "Valor Da Venda:";
            this.LblValorVenda.Click += new System.EventHandler(this.LblValorVenda_Click);
            // 
            // TxtValordaVenda
            // 
            this.TxtValordaVenda.Location = new System.Drawing.Point(107, 26);
            this.TxtValordaVenda.Name = "TxtValordaVenda";
            this.TxtValordaVenda.Size = new System.Drawing.Size(149, 20);
            this.TxtValordaVenda.TabIndex = 1;
            // 
            // LblSalarioaReceber
            // 
            this.LblSalarioaReceber.AutoSize = true;
            this.LblSalarioaReceber.Location = new System.Drawing.Point(6, 61);
            this.LblSalarioaReceber.Name = "LblSalarioaReceber";
            this.LblSalarioaReceber.Size = new System.Drawing.Size(95, 13);
            this.LblSalarioaReceber.TabIndex = 2;
            this.LblSalarioaReceber.Text = "Salario a Receber:";
            // 
            // TxtSalarioReceber
            // 
            this.TxtSalarioReceber.Location = new System.Drawing.Point(107, 58);
            this.TxtSalarioReceber.Name = "TxtSalarioReceber";
            this.TxtSalarioReceber.Size = new System.Drawing.Size(149, 20);
            this.TxtSalarioReceber.TabIndex = 3;
            // 
            // BtCalcula
            // 
            this.BtCalcula.Location = new System.Drawing.Point(698, 415);
            this.BtCalcula.Name = "BtCalcula";
            this.BtCalcula.Size = new System.Drawing.Size(75, 23);
            this.BtCalcula.TabIndex = 6;
            this.BtCalcula.Text = "&Calcular";
            this.BtCalcula.UseVisualStyleBackColor = true;
            this.BtCalcula.Click += new System.EventHandler(this.BtCalcula_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtCalcula);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TxtSalarioBruto);
            this.Controls.Add(this.LblSalarioBruto);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.GroupBFunção);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Calcula Salario de Vendedor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GroupBFunção.ResumeLayout(false);
            this.GroupBFunção.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.GroupBox GroupBFunção;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.Label LblSalarioBruto;
        private System.Windows.Forms.RadioButton RbOutra;
        private System.Windows.Forms.RadioButton RbVendedor;
        private System.Windows.Forms.TextBox TxtSalarioBruto;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TxtSalarioReceber;
        private System.Windows.Forms.Label LblSalarioaReceber;
        private System.Windows.Forms.TextBox TxtValordaVenda;
        private System.Windows.Forms.Label LblValorVenda;
        private System.Windows.Forms.Button BtCalcula;
    }
}

